
import express from 'express';
import dotenv from 'dotenv';
import cors from 'cors';
import axios from 'axios';
import FormData from 'form-data';

dotenv.config();

//const openai = new OpenAI({
//	apiKey: process.env.OPENAI_API_KEY,

//});

//const openai = new OpenAIApi(configuration);

const app = express();

app.use(cors());

app.use(express.json());

app.get('/', async (req, res) => {
   res.status(200).send({
	message: 'Hello from CodeX',
  })
});

app.post('/', async (req, res) => {
	try{
		const prompt = req.body.prompt;
                const formData = new FormData();
                formData.append('prompt', prompt);
                formData.append('output_format', 'webp')

                //const response = await openai.({
		//	model: "dall-e-3",
                //        prompt: `${prompt}`,
                //        n: 1,
                //        size: "1024x1024",
		//});
                const response = await axios.post(`https://api.stability.ai/v2beta/stable-image/generate/core`,
            formData,
            {
                headers: { 
                    Authorization: `Bearer sk-SEsR3ZPzdBvxPCwOR7q2qASlzyjlhhZo74baYRWXVp9Evqcb`, 
                    Accept: 'image/*', 
                },
                responseType: 'arraybuffer'
            }
        );
        if (response.status === 200) {
            res.setHeader('Content-Type', 'image/webp');
            res.status(200).send(response.data);
        } else {
            throw new Error(`${response.status}: ${response.data.toString()}`);
        }		

	} catch(error) {
		console.log(error);
                res.status(500).send({ error })
	}

})

app.listen(5000, () => console.log('Server is running on port http://localhost:5000'));

